package application;

import javafx.scene.control.ComboBox;

public class Course {

	public ComboBox course() {
		ComboBox combobox11=new ComboBox();
		
		combobox11.getItems().add("CSE115");
		combobox11.getItems().add("CSE115L");
		combobox11.getItems().add("CSE173");
		combobox11.getItems().add("CSE215");
		combobox11.getItems().add("CSE215L");
		combobox11.getItems().add("CSE225");
		combobox11.getItems().add("CSE225L");
		combobox11.getItems().add("CSE231");
		combobox11.getItems().add("CSE231L");
		combobox11.getItems().add("CSE311");
		combobox11.getItems().add("CSE311L");
		combobox11.getItems().add("CSE323");
		combobox11.getItems().add("CSE327");
		combobox11.getItems().add("CSE331");
		combobox11.getItems().add("CSE331L");
		combobox11.getItems().add("CSE373");
		combobox11.getItems().add("CSE323");
		combobox11.getItems().add("CSE425");
		combobox11.getItems().add("CSE299");
		combobox11.getItems().add("CSE499A");
		combobox11.getItems().add("CSE499B");
		combobox11.getItems().add("CSE498");
		combobox11.getItems().add("CSE401");
		combobox11.getItems().add("CSE417");
		combobox11.getItems().add("CSE418");
		combobox11.getItems().add("CSE426");
		combobox11.getItems().add("CSE473");
		combobox11.getItems().add("CSE491");
		combobox11.getItems().add("CSE411");
		combobox11.getItems().add("CSE427");
		combobox11.getItems().add("CSE428");
		combobox11.getItems().add("CSE428");
		combobox11.getItems().add("CSE492");
		combobox11.getItems().add("CSE422");
		combobox11.getItems().add("CSE438");
		combobox11.getItems().add("CSE482");
		combobox11.getItems().add("CSE485");
		combobox11.getItems().add("CSE486");
		combobox11.getItems().add("CSE493");
		combobox11.getItems().add("CSE433");
		combobox11.getItems().add("CSE435");
		combobox11.getItems().add("CSE413");
		combobox11.getItems().add("CSE414");
		combobox11.getItems().add("CSE415");
		combobox11.getItems().add("CSE494");
		combobox11.getItems().add("CSE440");
		combobox11.getItems().add("CSE445");
		combobox11.getItems().add("CSE465");
		combobox11.getItems().add("CSE467");
		combobox11.getItems().add("CSE470");
		combobox11.getItems().add("CSE419");
		combobox11.getItems().add("CSE446");
		combobox11.getItems().add("CSE447");
		combobox11.getItems().add("CSE448");
		combobox11.getItems().add("CSE449");
		combobox11.getItems().add("CSE442");
		combobox11.getItems().add("CSE496");
		
		combobox11.getItems().add("EEE154");
		combobox11.getItems().add("EEE141");
		combobox11.getItems().add("EEE141L");
		combobox11.getItems().add("EEE111");
		combobox11.getItems().add("EEE111L");
		combobox11.getItems().add("EEE452");
		
		combobox11.getItems().add("ENG102");
		combobox11.getItems().add("ENG103");
		combobox11.getItems().add("ENG111");
		
		combobox11.getItems().add("BEN205");
		
		combobox11.getItems().add("MAT116");
		combobox11.getItems().add("MAT120");
		combobox11.getItems().add("MAT125");
		combobox11.getItems().add("MAT130");
		combobox11.getItems().add("MAT250");
		combobox11.getItems().add("MAT350");
		combobox11.getItems().add("MAT361");
		
		combobox11.getItems().add("PHY107");
		combobox11.getItems().add("PHY107L");
		combobox11.getItems().add("PHY108");
		combobox11.getItems().add("PHY108L");
		
		combobox11.getItems().add("CHE101");
		combobox11.getItems().add("CHE101L");
		
		combobox11.getItems().add("BIO103");
		combobox11.getItems().add("BIO103L");
		
		combobox11.getItems().add("POL101");
		combobox11.getItems().add("POL104");
		
		combobox11.getItems().add("HIS102");
		combobox11.getItems().add("HIS103");
		
		combobox11.getItems().add("PHI104");
		
		combobox11.getItems().add("ECO101");
		combobox11.getItems().add("ECO104");
		
		combobox11.getItems().add("SOC101");
		combobox11.getItems().add("ENV203");
		combobox11.getItems().add("ANT101");
		combobox11.getItems().add("GEO205");
		
		combobox11.setPromptText("Select Course");
		return combobox11;
	}
}
